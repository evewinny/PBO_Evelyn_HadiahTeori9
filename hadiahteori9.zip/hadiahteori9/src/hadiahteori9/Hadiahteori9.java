/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hadiahteori9;

/**
 *
 * @author Evelyn
 */
import javax.swing.*;
import java.awt.event.*;

public abstract class Hadiahteori9 implements ActionListener {

    /**
     * @param args the command line arguments
     */
    private static void createAndShowGUI() {
           JFrame frame = new JFrame("Hadiah Teori 9"); frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
           frame.setBounds(400,400,400,400);
           frame.getContentPane().setLayout(null);
           
           JButton button1 = new JButton("Munculkan Nama");
           frame.getContentPane().add(button1);
           button1.setBounds(40,50,200,20);
           
           JButton button2 = new JButton("Munculkan NIM");
           frame.getContentPane().add(button2);
           button2.setBounds(40,100,200,20);
           
           JButton button3 = new JButton("Munculkan Alamat");
           frame.getContentPane().add(button3);
           button3.setBounds(40,150,200,20);
           
           Hadiahteori9 app = new Hadiahteori9() {
               @Override
               public void actionPerformed(ActionEvent e) {
                   throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
               }
           };
           app.label1 = new JLabel();
           app.label1.setBounds(250,40,200,40);
           frame.getContentPane().add(app.label1);
           
           app.label2 = new JLabel();
           app.label2.setBounds(250,100,200,20);
           frame.getContentPane().add(app.label2);
           
           app.label3 = new JLabel();
           app.label3.setBounds(250,150,200,20);
           frame.getContentPane().add(app.label3);
           
           button1.addActionListener(new ActionListener() {
                   public void actionPerformed(ActionEvent e) {
                   app.actionPerformed1();
                   }
           });
    
           button2.addActionListener(new ActionListener() {
                   public void actionPerformed(ActionEvent e) {
                   app.actionPerformed2();
                   }
            });
                   
           button3.addActionListener(new ActionListener(){
                   public void actionPerformed(ActionEvent e) {
                   app.actionPerformed3();
                   }
            });
            frame.setVisible(true);
    }
           public void actionPerformed1() {
               label1.setText("Evelyn Winny");
           }
           public void actionPerformed2() {
               label2.setText("51018005");
           }
           public void actionPerformed3() {
               label3.setText("Jl. Serigala");
           }
    public static void main(String[] args) {
        // TODO code application logic here
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI();
            }
        });
    }
JLabel label1, label2, label3;    
}
